Note that although the file currently uses a 
Spanish-English and a Japanese-English wordlist, 
however it can use any Language-Language wordlist 
which can be written in english alphabet. 

The Teasers work on the principle of comparing
the spellings, so they will work with other
languages as well.

e.g. Even an English-English wordlist can also
be used (in which...
"Word" = list of difficult english words
"Meaning" = list of their easy english words)


- Amit Bhola
  amit_aromatic@yahoo.com