In Line 45 of the code, initgraph function is called in which path is given to the BGI directory of the Turbo C++ compiler as "c:\\tc\\bgi"

If in your PC, the BGI folder is at some other path, then write that path in the code.