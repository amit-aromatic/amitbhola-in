DEBACLE III
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
This game was made in Borland International, Inc's Turbo C++ compiler version 3.0 on a Windows XP (32 bit) machine at time around 2009

As on 2017, the 32 bit operating systems are obsolete and don't run the 32 bit EXE files compiled on above compilers. So to run these programs on 64 bit machines, following are the suggestions :-

(1) Install the DOSBox application to emulate 32 bit environment.
    * Visit http://www.dosbox.com
    * The compiler is already included in zip file turboc.zip

(2) Compile the included source codes in a modern compiler like Dev-C++ and change the source codes suitably for any compiler compatibility issues.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

- Amit Bhola
  amit_aromatic@yahoo.com