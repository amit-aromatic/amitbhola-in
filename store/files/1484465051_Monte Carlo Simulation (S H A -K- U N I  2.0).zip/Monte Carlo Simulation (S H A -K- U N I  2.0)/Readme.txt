In case the program does not work, 
please try again after ensuring that the macros are enabled. 
Close the file and reopen it if necessary. 

If the Excel is looking for amitbholaFunctions.xlam addin,
(broken data link errors..) then that file is also enclosed. 
Try editing the data link source from "Data>Edit Links" 
menu in Excel, go for change source and browse to this .xlam file.

In case still the problem exists, or any type of support is
required, please contact me

-----------------------------------------
Although all known care has been taken to ensure that there are no bugs in the programs, 
however it is understood that these are not professionally made and tested. These are shared "as is" 
and it is upto user's discretion and judgment to use these for any purpose.


- Amit Bhola
  amit_aromatic@yahoo.com