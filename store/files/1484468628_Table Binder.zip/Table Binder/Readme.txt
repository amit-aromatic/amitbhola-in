Although all known care has been taken to ensure that there are no bugs in the programs, 
however it is understood that these are not professionally made and tested. These are shared "as is" 
and it is upto user's discretion and judgment to use these for any purpose.
